#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""tuya_iot version."""

VERSION = "0.4.4"